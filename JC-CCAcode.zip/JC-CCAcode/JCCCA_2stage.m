function [u, v, r, lossf] = JCCCA_2stage(X, Y, Lx, params)
% the difference here is instead of alpha|Xu|<=1, we have alpha|u|<=1
% and using a different way to update v
% perform joint constrained CCA for estimating individulized u
% for each data set and common v for the second data sets
% Input:
% X, is the cellarray, with each cell corresponding to the voxel signals of
% one subject, X{i} is with the dimension of T*Pi
% Y, is the cellarray,with each cell corresponding to the ROI level signals
% of one subject, Y{i} is with the dimension of T*Q
% the length of X and Y cells is S, and Xi corresponds to Yi for the same i

[u1, v1, r1, lossf] = JCCCA(X, Y, Lx, params);
S = length(X);
thre = 0.5*10^-2;

% with estimated features, without using sparse penalty
% for Y
idxv = find(v1);
for s = 1:S
    Ytmp = Y{s};
    Ynew{s} = Ytmp(:,idxv);
    utmp = u1{s};
    utmp(abs(utmp)<mean(abs(utmp))*thre) = 0;
    idxu{s} = find(utmp);
    Xtmp = X{s};
    Xnew{s} = Xtmp(:,idxu{s});
    Ltmp = Lx{s};
    Lxnew{s} = Ltmp(idxu{s}, idxu{s});
end

flag = 1;
if isempty(idxv)
    flag = 0;
end
Uflag = cellfun(@isempty, idxu);
if nnz(Uflag)>0
    flag = 0;
end

if flag
    clear lossf
    params.beta_u = 0;
    params.c_v = 1000;
    params.gamma_u = params.gamma_u;
    
    [u2, v2, r, lossf] = JCCCA(Xnew, Ynew, Lxnew, params);
    
    % recover the original u and v
    v = zeros(size(v1));
    v(idxv) = v2;
    for s = 1:S
        utmp = zeros(size(u1{s}));
        utmp(idxu{s}) = u2{s};
        u{s} = utmp;
    end
else
    v = v1;
    u = u1;
    r = r1;
end

end
