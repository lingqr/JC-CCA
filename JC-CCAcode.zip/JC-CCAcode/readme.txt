Joint Constrained Canonical Correlation Analysis (JC-CCA)

Main Function: JCCCA_k.m
Input: X, is the cellarray, with each cell corresponding to the voxel signals of one subject, X{i} is with the dimension of T*Pi.
          Y, is the cellarray, with each cell corresponding to the ROI level signals of one subject, Y{i} is with the dimension of T*Q.
          The length of X and Y cells is S, and Xi corresponds to Yi for the same i. The data of each cell are normalized to have zero mean and unit variance.
          Lx, is the cellarray, with each cell corresponding to the Laplacian matrix of one subject, Lx{i} is with the dimension of Pi*Pi.
          params, is the struct, containing the normalization tunning parameters [alpha_u, alpha_v] (usually 0.1), the sparsity tunning parameter for v - c_v (usually ranges from 1 to 10), the sparsity parameter and the spatially smoothing parameter, [beta_u, gamma_u] (usually range from 0.01 to 1).
          K, is the number of canonical correlation variables.
Output:  u, is the cellarray (length K), with each cell be the cellarray (length S) corresponding to the canonical correlation loadings of X, u{k}{i} is with the dimension of Pi*1.
              v, is the cellarray (length K), with each cell corresponding to the canonical correlation loadings of Y, v{k} is with the dimension of Q*1. 
              r, is the cellarray (length K), with each cell corresponding to the correlation coefficients of X{i}u{k}{i} and Y{i}v{k}.
              lossf, is the cellarray (length K), with each cell corresponding to the loss function.
Related Functions: JCCCA.m, JCCCA_2stage.m, JCCCA_component.m

Functions Related to Cross Validation for Choosing Parameters:
Main Algorithm: JCCCA_cv.m.
CV is the number of folds for cross validation. 
There are three parameters we need to choose: the sparsity tunning parameter for v - c_v, the sparsity parameter and the spatially smoothing parameter, [beta_u, gamma_u].

Functions Related to L1-Sparse CCA: see the paper [A penalized matrix decomposition, with applications to sparse principal components and canonical correlation analysis] by DANIELA M. WITTEN,  ROBERT TIBSHIRANI and TREVOR HASTIE in Biostatistics.
maxL1L2.m implements Lemma 2.2. in the paper (use BinarySearch.m, soft_threshold.c (soft thresholding operator) and projl2.m (projection on L2-ball))
Please mex soft_threshold.c beforing using it (run install_mex.m).
