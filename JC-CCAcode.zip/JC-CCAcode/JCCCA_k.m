function [u, v, r, lossf] = JCCCA_k(X, Y, Lx, params, K)
% return the first Kth canonical correlation loadings

S = length(X);
Xnow = X;
Ynow = Y;
r = cell(1,K);
lossf = cell(1,K);

[utemp, vtemp, rtemp, lossftemp] = JCCCA_2stage(Xnow, Ynow, Lx, params);
u{1} = utemp;
v{1} = vtemp;
r{1} = rtemp;
lossf{1} = lossftemp;
for s = 1:S
    Xtemp{s} = Xnow{s} - Xnow{s}*utemp{s}*utemp{s}'/(utemp{s}'*utemp{s});
    Xtemp{s} = bsxfun(@minus, Xtemp{s}, mean(Xtemp{s}));
    Xnow{s} = bsxfun(@rdivide, Xtemp{s}, std(Xtemp{s}));
    Xnow{s}(isnan(Xnow{s})) = Xtemp{s}(isnan(Xnow{s}));
    
    Ytemp{s} = Ynow{s} - Ynow{s}*vtemp*vtemp'/(vtemp'*vtemp);
    Ytemp{s} = bsxfun(@minus, Ytemp{s}, mean(Ytemp{s}));
    Ynow{s} = bsxfun(@rdivide, Ytemp{s}, std(Ytemp{s}));
    Ynow{s}(isnan(Ynow{s})) = Ytemp{s}(isnan(Ynow{s}));
end

for k = 2:K
    clear [rtemp, lossftemp];
    [u, v, rtemp, lossftemp] = JCCCA_component(Xnow, Ynow, Lx, params, u, v);
    r{k} = rtemp;
    lossf{k} = lossftemp;
    for s = 1:S
        Xtemp{s} = Xnow{s} - Xnow{s}*u{k}{s}*utemp{s}'/(u{k}{s}'*u{k}{s});
        Xtemp{s} = bsxfun(@minus, Xtemp{s}, mean(Xtemp{s}));
        Xnow{s} = bsxfun(@rdivide, Xtemp{s}, std(Xtemp{s}));
        Xnow{s}(isnan(Xnow{s})) = Xtemp{s}(isnan(Xnow{s}));
        
        Ytemp{s} = Ynow{s} - Ynow{s}*v{k}*v{k}'/(v{k}'*v{k});
        Ytemp{s} = bsxfun(@minus, Ytemp{s}, mean(Ytemp{s}));
        Ynow{s} = bsxfun(@rdivide, Ytemp{s}, std(Ytemp{s}));
        Ynow{s}(isnan(Ynow{s})) = Ytemp{s}(isnan(Ynow{s}));
    end
end