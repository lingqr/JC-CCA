function u=maxL1L2(a,c)
% implement Lemma 2.2. in [A penalized matrix decomposition, with applications to
%sparse principal components and canonical correlation analysis] 

    if c>=sqrt(length(a))
        u=projl2(a);
    elseif c<=1
        [v, idx]=max(abs(a));
        u=zeros(length(a),1);
        u(idx)=sign(a(idx))*c;
    else 
        delta=BinarySearch(a,c);
        u=projl2(soft_threshold(a, delta));
    end
    
end  