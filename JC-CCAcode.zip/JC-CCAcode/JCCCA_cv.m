function [u, v, r, params, res, lossf] = JCCCA_cv(X, Y, Lx, CV, c_v_tot, beta_u_tot, gamma_u_tot)
% cross validation for choosing the parameters
% there are three parameters we need to choose
% 1. the sparsity tunning parameter for v - c_v, which is indepedent with the the
% tunning parameters for u, therefore, we first choose v according to
% largest averaged correlation values
% 2. the sparsity parameters and the spatially smoothing parameters,
% [beta_u, gamma_u] which is choosing according to grid search.

S = length(X);
T = size(X{1}, 1);

% split data into different folds
len = round(T/CV);
for i = 1:CV
    idxtest = len*(i-1)+1:i*len;
    idxtrain = setdiff(1:T, idxtest);
    
    for s = 1:S
        xtest{s} = X{s}(idxtest, :);
        ytest{s} = Y{s}(idxtest, :);
        xtrain{s} = X{s}(idxtrain, :);
        ytrain{s} = Y{s}(idxtrain, :);
    end
    cvXtrain{i} = xtrain;
    cvXtest{i} = xtest;
    cvYtrain{i} = ytrain;
    cvYtest{i} = ytest;
end

params.alpha_u = 0.1;
params.alpha_v = 0.1;
params.beta_u = 0.1;
params.gamma_u = 10;

% first choose c_v
hh = waitbar(0, 'Choosing cv');
N = length(c_v_tot);
for i = 1:N
    params.c_v = c_v_tot(i);
    for j = 1:CV
        [ut, vt] = JCCCA_2stage(cvXtrain{j}, cvYtrain{j}, Lx, params);
        % calculate the correlation
        rt(j) = 0;
        xtest = cvXtest{j};
        ytest = cvYtest{j};
        for s = 1:S
            rt(j) = rt(j) + corr(xtest{s}*ut{s}, ytest{s}*vt);
        end
        rt(j) = rt(j)/S;
    end
    rv(i) = mean(rt);
    res.vcv{i}.u = ut;
    res.vcv{i}.v = vt;
    res.vcv{i}.params = params;
    waitbar(i/N);
end
close(hh);

% choose c_v according to the largest rv
id = find(rv == max(rv));
c_v = c_v_tot(id(end));

params.alpha_u = 0.1;
params.alpha_v = 0.1;
params.c_v = c_v;
N1 = length(beta_u_tot);
N2 = length(gamma_u_tot);

clear rt
hh = waitbar(0, 'Choosing betau and gammau');
ctr = 1;
N = N1*N2;
for i = 1:N1
    for j = 1:N2
        params.beta_u = beta_u_tot(i);
        params.gamma_u = gamma_u_tot(j);
        for k = 1:CV
            [ut, vt] = JCCCA_2stage(cvXtrain{k}, cvYtrain{k}, Lx, params);
            % calculate the correlation
            rt(k) = 0;
            xtest = cvXtest{k};
            ytest = cvYtest{k};
            for s = 1:S
                rt(k) = rt(k) + corr(xtest{s}*ut{s}, ytest{s}*vt);
            end
            rt(k) = rt(k)/S;
        end
        ru(i, j) = mean(rt);
        waitbar(ctr/N);
        res.ucv{ctr}.u = ut;
        res.ucv{ctr}.v = vt;
        res.ucv{ctr}.params = params;
        ctr = ctr + 1;
    end
end
close(hh);

[id1, id2] = find(ru == max(ru(:)));
beta_u = beta_u_tot(id1(end));
gamma_u = gamma_u_tot(id2(end));

params.alpha_u = 0.1;
params.alpha_v = 0.1;
params.c_v = c_v;
params.beta_u = beta_u;
params.gamma_u = gamma_u;
[u, v, r, lossf] = JCCCA_2stage(X, Y, Lx, params);

end