function [u, v, r, lossf] = JCCCA(X, Y, Lx, params)
% the difference here is instead of alpha|Xu|<=1, we have alpha|u|<=1
% and using a different way to update v
% perform joint constrained CCA for estimating individulized u
% for each data set and common v for the second data sets
% Input:
% X, is the cellarray, with each cell corresponding to the voxel signals of
% one subject, X{i} is with the dimension of T*Pi
% Y, is the cellarray,with each cell corresponding to the ROI level signals
% of one subject, Y{i} is with the dimension of T*Q
% the length of X and Y cells is S, and Xi corresponds to Yi for the same i

S = length(X);
if length(Y)~=S
    error('Input data X and Y should have the same length (the # of subjects)');
end

% check the dimension of each dataset in Y, data sets in Y should have the same dimension %
% each data sets in X could have the different dimensions
[xrs, xcs] = cellfun(@size, X);
[yrs, ycs] = cellfun(@size, Y);

if mean(xrs) == mean(yrs)
    T = mean(xrs);
else
    error('The sample lengths are different in X and Y');
end

if var(ycs)>0
    error('Input data in Y must have the same number of variables (features)');
else
    Q = mean(ycs);
end

% estimate the sample covariance matrix
sYY = zeros(Q,Q);
for i = 1:S
    XX{i} = X{i}'*X{i};
    YY{i} = Y{i}'*Y{i};
    XY{i} = X{i}'*Y{i};
    YX{i} = Y{i}'*X{i};
    sYY = sYY + YY{i};
end

% assign the parameters
alpha1 = params.alpha_u;
alpha2 = params.alpha_v;
beta1 = params.beta_u;
c2 = params.c_v;
gamma1 = params.gamma_u;

% initialization
for s = 1:S
    u{s} = randn(xcs(s), 1)./xcs(s);
    D1{s} = diag(ones(xcs(s), 1));
    Iu{s} = eye(xcs(s));
end
v = randn(Q, 1)./Q;
D2 = diag(ones(Q, 1));
Iv = eye(Q);

ctr = 1;
iter = 100;
err = 1e-5;

while ctr<iter
    % with fixed v, update each u
    diff_u = 0;
    for s = 1:S
        u_new = (2*alpha1*Iu{s} + beta1*D1{s} + 2*gamma1*Lx{s}) \ (XY{s}*v);
        u_new(isnan(u_new)) = eps;
        scale1 = sqrt(u_new'*u_new);
        u_new = u_new./scale1;
        
        diff_u = diff_u + max(abs(u_new-u{s}));
        u{s} = u_new;
        D1{s} = diag(1./sqrt(u{s}.^2+eps));
        clear u_new
    end
    diff_u = diff_u/S;
    
    % update v
    RV = zeros(Q,1);
    for s = 1:S
        RV = RV + YX{s}*u{s};
    end
    v_new = maxL1L2(RV./S, c2);
    %v_new = (2*alpha2*S*Iv + beta2*S*D2) \ RV;
    v_new(isnan(v_new)) = eps;
    %scale2 = sqrt(v_new'*v_new);
    %v_new = v_new./scale2;
    diff_v = max(abs(v_new - v));
    v = v_new;
    %D2 = diag(1./sqrt(v.^2+eps));

    lossval = 0;
    for s = 1:S
        lossval = lossval - u{s}'*XY{s}*v + alpha1*u{s}'*u{s} + alpha2*v'*v...
            + beta1*sum(abs(u{s})) + gamma1*u{s}'*Lx{s}*u{s};
    end
    
    lossf(ctr) = lossval;
    
    if (diff_u<err || diff_v<err)
        break
    end
    ctr = ctr + 1;
end

if sum(u{1}) < 0
    v = -v;
    for s = 1:S
        u{s} = -u{s};
    end
end

% estimated correlation coefficient
for s = 1:S
    r(s) = corr(X{s}*u{s}, Y{s}*v);
end

end